const DEFAULT_API = "http://127.0.0.1:8000";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => chrome.contextMenus.create({ id: "ms-check-selection", title: "Check with Misinformation Shield", contexts: ["selection"] }));
  chrome.storage.sync.get({ apiBase: DEFAULT_API }, (settings) => {
    chrome.storage.sync.set({ apiBase: settings.apiBase || DEFAULT_API });
  });
});

async function getApiBase() {
  const { apiBase = DEFAULT_API } = await chrome.storage.sync.get({ apiBase: DEFAULT_API });
  return apiBase.replace(/\/+$/, "");
}

async function requestAnalysis(path, text, language, timeoutMs) {
  const apiBase = await getApiBase();
  const started = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${apiBase}${path}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, language }), signal: controller.signal
    });
    const raw = await response.text();
    if (!response.ok) throw new Error(`Backend returned HTTP ${response.status}: ${raw.slice(0, 250)}`);
    let result;
    try { result = JSON.parse(raw); } catch { throw new Error("Backend returned an invalid JSON response."); }
    if (!result || typeof result.label !== "string" || !Array.isArray(result.claims)) throw new Error("Backend response is missing expected analysis fields.");
    return { result, apiBase, elapsedMs: Date.now() - started };
  } finally { clearTimeout(timer); }
}

async function broadcastStage(stage, message) {
  await chrome.storage.session.set({ analysisStage: stage, analysisMessage: message });
  chrome.runtime.sendMessage({ type: "MS_ANALYSIS_PROGRESS", stage, message }).catch(() => {});
}

async function runStagedAnalysis(text, language, page, sendInitialResponse) {
  const current = await chrome.storage.session.get({ activeAnalysisUntil: 0 });
  if (current.activeAnalysisUntil > Date.now()) {
    sendInitialResponse?.({ ok: false, error: "An analysis is already running. Wait for it to finish before starting another." });
    return;
  }
  await chrome.storage.session.set({ activeAnalysisUntil: Date.now() + 240000, analysisInProgress: true });
  const startedAt = Date.now();
  try {
    await broadcastStage("classifying", "Identifying claims and running the trained classifier…");
    const { result: preliminary, apiBase, elapsedMs: initialApiMs } = await requestAnalysis("/analyze/initial", text, language, 10000);
    const preview = { result: preliminary, page, language, apiBase, stage: "preliminary", startedAt, receivedAt: Date.now(), clientTimingsMs: { initialApi: initialApiMs, extraction: page.extractionMs ?? null } };
    const storedPreview = { ...preview, result: { ...preliminary, claims: [], candidate_claims: [], extraction_summary: { ...preliminary.extraction_summary, excluded_statements: [] } } };
    await chrome.storage.session.set({ latestAnalysis: storedPreview, pendingDetail: { text, language, page, apiBase, startedAt, initialApiMs }, analysisInProgress: true, latestError: "" });
    sendInitialResponse?.({ ok: true, payload: preview });
    chrome.runtime.sendMessage({ type: "MS_PRELIMINARY_READY", payload: preview, text }).catch(() => {});
    await broadcastStage("detailed", "Preliminary model signal is ready. Retrieving claim-level fact-check evidence…");
  } catch (error) {
    const detail = error.name === "AbortError" ? "The initial classifier request exceeded 10 seconds. Check that the backend is running and ready." : error.message;
    await chrome.storage.session.remove("pendingDetail");
    await chrome.storage.session.set({ analysisInProgress: false, activeAnalysisUntil: 0, latestError: detail, analysisStage: "error", analysisMessage: detail });
    sendInitialResponse?.({ ok: false, error: detail });
    chrome.runtime.sendMessage({ type: "MS_ANALYSIS_FAILED" }).catch(() => {});
  }
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "ms-check-selection" || !info.selectionText?.trim() || !tab?.id) return;
  const text = info.selectionText.trim().slice(0, 100000);
  const page = { title: tab.title || "Selected text", url: tab.url || "", domain: (() => { try { return new URL(tab.url).hostname; } catch { return ""; } })(), selectedText: true };
  const { language = "en" } = await chrome.storage.sync.get({ language: "en" });
  await chrome.storage.session.remove(["latestAnalysis", "latestError"]);
  await chrome.storage.session.set({ analysisInProgress: true, analysisStartedAt: Date.now() });
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
    runStagedAnalysis(text, language, page, null);
  } catch (error) {
    await chrome.storage.session.set({ analysisInProgress: false, latestError: error.message });
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "MS_ANALYZE_TEXT") {
    runStagedAnalysis(message.text, message.language, message.page || {}, sendResponse);
    return true;
  }
  if (message?.type === "MS_ANALYSIS_PROGRESS") {
    broadcastStage(message.stage, message.message).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "MS_ANALYSIS_FINISHED") {
    chrome.storage.session.set({ analysisInProgress: false, activeAnalysisUntil: 0 }).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "MS_ANALYSIS_CANCELLED") {
    const reason = message.reason || "Detailed analysis was cancelled when the side panel closed.";
    chrome.storage.session.remove("pendingDetail").then(() => chrome.storage.session.set({ analysisInProgress: false, activeAnalysisUntil: 0, analysisStage: "cancelled", analysisMessage: reason, latestError: reason })).then(() => {
      chrome.runtime.sendMessage({ type: "MS_ANALYSIS_FAILED" }).catch(() => {});
      sendResponse({ ok: true });
    });
    return true;
  }
  if (message?.type === "MS_OPEN_PANEL") {
    chrome.sidePanel.open({ tabId: message.tabId }).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});
