(() => {
  if (globalThis.__misinfoShieldContentLoaded) return;
  globalThis.__misinfoShieldContentLoaded = true;

  const EXCLUDED = "nav,footer,header,aside,form,button,[hidden],[aria-hidden='true'],[role='navigation'],[role='complementary'],.advertisement,.ad,.ads,.social-share,.newsletter";
  const MAX_PARAGRAPHS = 400;
  const MAX_CHARS = 100000;

  function extractArticle() {
    const started = performance.now();
    const root = document.querySelector("[itemprop='articleBody']")
      || document.querySelector("article")
      || document.querySelector("main")
      || document.querySelector("[role='main']")
      || document.body;
    const collectParagraphs = (container) => [...container.querySelectorAll("p, h1, h2, h3, blockquote")]
      .slice(0, MAX_PARAGRAPHS)
      .filter((node) => !node.closest(EXCLUDED))
      .map((node) => (node.textContent || "").replace(/[\t\u00a0 ]+/g, " ").replace(/\s*\n\s*/g, " ").trim())
      .filter((value) => value.length >= 35);
    let paragraphs = collectParagraphs(root);
    if (paragraphs.join("\n\n").length < 80 && root !== document.body) paragraphs = collectParagraphs(document.body);
    const text = paragraphs.join("\n\n").slice(0, MAX_CHARS);
    return {
      title: document.querySelector("meta[property='og:title']")?.content || document.querySelector("h1")?.textContent?.trim() || document.title,
      url: location.href,
      domain: location.hostname,
      text,
      extractionMethod: root.matches("[itemprop='articleBody'], article, main, [role='main']") ? "article-paragraphs" : "page-paragraphs",
      extractionDurationMs: Math.round(performance.now() - started)
    };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    try {
      if (message?.type === "MS_EXTRACT_ARTICLE") sendResponse(extractArticle());
      else if (message?.type === "MS_GET_PAGE_INFO") sendResponse({ title: document.title, url: location.href, domain: location.hostname });
      return false;
    } catch (error) {
      sendResponse({ error: error?.message || "Article extraction failed." });
      return false;
    }
  });
})();
