const host = document.getElementById("content");
chrome.storage.session.get(["latestAnalysis", "latestError", "analysisInProgress", "analysisStage", "analysisMessage"]).then(({ latestAnalysis, latestError, analysisInProgress, analysisStage, analysisMessage }) => {
  if (latestAnalysis?.stage === "preliminary") { renderPreliminary(latestAnalysis); if (latestError) showEvidenceError(latestError); }
  else if (latestAnalysis) render(latestAnalysis);
  else if (latestError) showError(latestError);
  else if (analysisInProgress) showLoading(analysisMessage || stageMessage(analysisStage));
});
chrome.storage.session.get("pendingDetail").then(({ pendingDetail }) => {
  if (pendingDetail) startDetailed(pendingDetail);
});
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "MS_ANALYSIS_PROGRESS") showLoading(message.message);
  if (message?.type === "MS_PRELIMINARY_READY") {
    renderPreliminary(message.payload);
    if (message.text) startDetailed({ ...message.payload, text: message.text });
  }
  if (message?.type === "MS_ANALYSIS_UPDATED") render(message.payload);
  if (message?.type === "MS_ANALYSIS_FAILED") chrome.storage.session.get(["latestError", "latestAnalysis"]).then(({ latestError, latestAnalysis }) => {
    if (latestAnalysis?.stage === "preliminary") showEvidenceError(latestError || "Detailed evidence retrieval did not complete.");
    else showError(latestError || "Analysis failed.");
  });
});

let elapsedTimer;
let analysisStartedAt = Date.now();
let activeDetailController;
const startedDetailIds = new Set();
function showLoading(message = "Preparing analysis…") {
  clearInterval(elapsedTimer);
  host.innerHTML = `<section class="card"><b>${escapeHtml(message)}</b><p id="elapsed-time" class="muted"></p></section>`;
  updateElapsed(); elapsedTimer = setInterval(updateElapsed, 1000);
}
function updateElapsed() { const node = document.getElementById("elapsed-time"); if (node) node.textContent = `${Math.floor((Date.now() - analysisStartedAt) / 1000)}s elapsed`; }
function stageMessage(stage) { return ({ extracting: "Extracting article content…", classifying: "Identifying claims and running the classifier…", detailed: "Retrieving claim-level fact-check evidence…" })[stage] || "Preparing analysis…"; }

function renderPreliminary(payload) {
  clearInterval(elapsedTimer);
  analysisStartedAt = payload.startedAt || Date.now();
  const data = payload.result || {};
  const label = data.preliminary_label || "Unable to Assess";
  const score = typeof data.classifier_score === "number" ? `${Math.round(data.classifier_score * 100)}%` : "Unavailable";
  const timings = data.timings_ms || {};
  const clientTime = payload.clientTimingsMs?.initialApi;
  host.innerHTML = `<section class="card overall risk-unable"><span class="badge risk-unable">PRELIMINARY · EVIDENCE PENDING</span><h1>${escapeHtml(label)}</h1><p>${escapeHtml(data.explanation || "This model signal has not been verified against fact-check evidence.")}</p></section><section class="card metadata"><div><b>Classifier prediction</b><span>${escapeHtml(data.classifier_label || "Unavailable")}</span></div><div><b>Classifier score</b><span>${score}</span></div><div><b>Language</b><span>${payload.language === "hi" ? "Hindi" : "English"}</span></div><div><b>Backend classification</b><span>${Number(timings.total || 0).toFixed(0)} ms</span></div><div><b>Extension → API</b><span>${typeof clientTime === "number" ? `${clientTime} ms` : "Pending"}</span></div><div><b>Article extraction</b><span>${typeof payload.clientTimingsMs?.extraction === "number" ? `${payload.clientTimingsMs.extraction} ms` : "Selected text"}</span></div></section><section class="card progress-card"><b>Evidence verification is continuing</b><p class="muted">Claim-level fact-check search is running. The final assessment will replace this preliminary model signal when the backend finishes.</p><p id="elapsed-time" class="muted"></p></section>`;
  updateElapsed(); elapsedTimer = setInterval(updateElapsed, 1000);
}
function showEvidenceError(message) {
  clearInterval(elapsedTimer);
  const banner = document.createElement("section"); banner.className = "card error";
  banner.textContent = `Evidence verification did not finish: ${message}. The preliminary model signal above is not a verified final result.`;
  host.prepend(banner);
}

async function startDetailed(input) {
  const key = String(input.startedAt || input.receivedAt || "");
  if (startedDetailIds.has(key) || !input.text) return;
  startedDetailIds.add(key);
  clearInterval(elapsedTimer);
  analysisStartedAt = input.startedAt || Date.now();
  await chrome.storage.session.remove("pendingDetail");
  const controller = new AbortController();
  activeDetailController = controller;
  const timer = setTimeout(() => controller.abort(), 180000);
  const requestStarted = Date.now();
  try {
    showLoading("Retrieving claim-level fact-check records and preparing final assessment…");
    const response = await fetch(`${input.apiBase}/analyze`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: input.text, language: input.language }), signal: controller.signal
    });
    const raw = await response.text();
    if (!response.ok) throw new Error(`Backend returned HTTP ${response.status}: ${raw.slice(0, 250)}`);
    let result;
    try { result = JSON.parse(raw); } catch { throw new Error("Backend returned an invalid JSON response."); }
    if (!result || typeof result.label !== "string" || !Array.isArray(result.claims)) throw new Error("Backend response is missing expected analysis fields.");
    const completed = { result, page: input.page || {}, language: input.language, apiBase: input.apiBase, stage: "complete", startedAt: input.startedAt, receivedAt: Date.now(), clientTimingsMs: { initialApi: input.clientTimingsMs?.initialApi ?? input.initialApiMs, detailedApi: Date.now() - requestStarted, extraction: input.clientTimingsMs?.extraction ?? input.page?.extractionMs ?? null } };
    await chrome.storage.session.set({ latestAnalysis: completed, analysisInProgress: false, latestError: "", analysisStage: "complete", analysisMessage: "Evidence analysis complete." });
    render(completed);
    chrome.runtime.sendMessage({ type: "MS_ANALYSIS_UPDATED", payload: completed }).catch(() => {});
  } catch (error) {
    const detail = error.name === "AbortError" ? "Detailed evidence analysis timed out after 180 seconds." : error.message;
    await chrome.storage.session.set({ analysisInProgress: false, latestError: detail, analysisStage: "error", analysisMessage: detail });
    showEvidenceError(detail);
    chrome.runtime.sendMessage({ type: "MS_DETAIL_FAILED" }).catch(() => {});
  } finally {
    clearTimeout(timer);
    activeDetailController = null;
    chrome.runtime.sendMessage({ type: "MS_ANALYSIS_FINISHED" }).catch(() => {});
  }
}

window.addEventListener("pagehide", () => {
  if (activeDetailController) {
    activeDetailController.abort();
    chrome.runtime.sendMessage({ type: "MS_ANALYSIS_CANCELLED" }).catch(() => {});
  }
});

function render(payload) {
  clearInterval(elapsedTimer);
  const data = payload.result || {};
  const label = data.label || "Unable to Assess";
  const risk = label === "Likely Genuine" ? "risk-genuine" : label === "Potentially Misleading" ? "risk-misleading" : "risk-unable";
  const page = payload.page || {};
  const claims = (data.claims || []).map((claim, index) => claimCard(claim, index)).join("");
  const excluded = data.extraction_summary?.excluded_statements || [];
  const timings = data.timings_ms || {};
  host.innerHTML = `<section class="card overall ${risk}"><h1>${escapeHtml(label)}</h1><p>${escapeHtml(data.explanation || "Review the available claim-level evidence.")}</p></section>
    <section class="card metadata"><div><b>Classifier prediction</b><span>${escapeHtml(data.classifier_label || "Unavailable")}</span></div><div><b>Classifier score</b><span>${typeof data.classifier_score === "number" ? `${Math.round(data.classifier_score * 100)}%` : "Not available"}</span></div><div><b>Relevant records</b><span>${Number(data.evidence_summary?.matching_records || 0)}</span></div><div><b>Backend time</b><span>${typeof timings.total === "number" ? `${(timings.total / 1000).toFixed(2)}s` : "Unavailable"}</span></div><div><b>Evidence search</b><span>${typeof timings.evidence_retrieval === "number" ? `${(timings.evidence_retrieval / 1000).toFixed(2)}s` : "Unavailable"}</span></div><div><b>Extension → API</b><span>${typeof payload.clientTimingsMs?.detailedApi === "number" ? `${payload.clientTimingsMs.detailedApi} ms` : "Unavailable"}</span></div><div><b>Language</b><span>${payload.language === "hi" ? "Hindi" : "English"}</span></div><div><b>Page</b><span>${escapeHtml(page.title || "Selected text")}</span></div><div><b>Source website</b><span>${page.url ? `<a href="${escapeAttr(safeUrl(page.url))}" target="_blank" rel="noopener">${escapeHtml(page.domain || page.url)}</a>` : escapeHtml(page.domain || "Not supplied")}</span></div></section>
    <p class="muted">${escapeHtml(data.evidence_status || "Evidence search status unavailable.")} Classifier confidence and evidence relevance are different signals.</p>
    <h2 class="section-title">Claim analysis (${(data.claims || []).length})</h2>${claims || `<div class="empty-state">${escapeHtml(data.explanation || "No factual claims were extracted.")}</div>`}
    <h2 class="section-title">Methodology</h2><section class="card"><p>${escapeHtml(data.extraction_summary?.method || "The backend did not return extraction method details.")}</p><p class="muted">No client-side predictions are generated. All labels and evidence below come from the configured backend response.</p>${excluded.length ? `<details><summary>Excluded statements (${excluded.length})</summary>${excluded.map((item) => `<div class="source">${escapeHtml(item.text)}<div class="score">Reason: ${escapeHtml(item.reason)}</div></div>`).join("")}</details>` : ""}</section>`;
}

function claimCard(claim, index) {
  const label = claim.label || "Unable to Assess";
  const risk = label === "Likely Genuine" ? "risk-genuine" : label === "Potentially Misleading" ? "risk-misleading" : "risk-unable";
  const classifierScore = typeof claim.classifier_score === "number" ? `${Math.round(claim.classifier_score * 100)}%` : "Unavailable";
  const assessment = claim.evidence_assessment || {};
  const sources = claim.evidence?.matches || [];
  const sourcesHtml = sources.length ? sources.map((source) => {
    const url = safeUrl(source.url);
    return `<div class="source"><div class="source-head">${escapeHtml(source.rating || "Rating unavailable")} · ${escapeHtml(source.publisher || source.provider || "Fact-check source")}</div><div>${escapeHtml(source.title || source.claim || "Fact-check record")}</div><div class="score">Evidence relevance: ${typeof source.similarity === "number" ? `${Math.round(source.similarity * 100)}%` : "Unavailable"} · Published rating direction: ${escapeHtml(source.published_rating_direction || "unknown")}</div>${url ? `<a href="${escapeAttr(url)}" target="_blank" rel="noopener">Open original fact-check ↗</a>` : ""}</div>`;
  }).join("") : `<div class="empty-state">${escapeHtml(claim.evidence?.status === "local_empty_live_off" ? "No sufficiently relevant fact-check match was found. No match is not a verdict." : "No fact-check records were returned for this claim.")}</div>`;
  const error = claim.evidence?.local_error || claim.evidence?.google_error;
  return `<article class="claim"><div class="claim-head"><span>Claim ${index + 1}</span><span class="badge ${risk}">${escapeHtml(label)}</span></div><div class="claim-text">${escapeHtml(claim.claim || "")}</div><div class="claim-meta"><span>Classifier: ${escapeHtml(claim.classifier_label || "Unavailable")} (${classifierScore})</span><span>Evidence: ${escapeHtml(assessment.verdict || "insufficient")}</span><span>Close matches: ${Number(assessment.strong_match_count || 0)}</span></div><p>${escapeHtml(claim.decision_reason || "No additional decision explanation returned.")}</p><details open><summary>Evidence and sources (${sources.length})</summary>${sourcesHtml}${error ? `<div class="error">Evidence lookup issue: ${escapeHtml(error)}</div>` : ""}</details></article>`;
}
function showError(message) { host.innerHTML = `<section class="card error"><b>Could not complete analysis</b><p>${escapeHtml(message)}</p><p>Check that the backend is running and that the configured URL is correct.</p></section>`; }
function safeUrl(value) { try { const url = new URL(value); return ["http:", "https:"].includes(url.protocol) ? url.href : ""; } catch { return ""; } }
function escapeHtml(value) { const node = document.createElement("span"); node.textContent = String(value ?? ""); return node.innerHTML; }
function escapeAttr(value) { return escapeHtml(value).replace(/"/g, "&quot;"); }
