const DEFAULT_API = "http://127.0.0.1:8000";
const byId = (id) => document.getElementById(id);
const articleButton = byId("analyze");
const selectedButton = byId("analyze-selection");
const output = byId("result");
let currentTab;
let pageInfo = {};

document.addEventListener("DOMContentLoaded", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab;
  pageInfo = { title: tab?.title || "Current page", url: tab?.url || "", domain: safeDomain(tab?.url) };
  byId("page-title").textContent = pageInfo.title;
  byId("page-domain").textContent = pageInfo.domain || "This browser page cannot be analyzed.";
  const settings = await chrome.storage.sync.get({ apiBase: DEFAULT_API, language: "en" });
  byId("api-base").value = settings.apiBase;
  byId("language").value = settings.language;
  checkBackend(settings.apiBase);
  const supported = /^https?:$/.test(safeProtocol(tab?.url));
  articleButton.disabled = !supported;
  selectedButton.disabled = !supported;
  if (!supported) byId("extract-status").textContent = "Browser internal pages and extension stores do not allow extraction.";
  if (supported) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      const info = await chrome.tabs.sendMessage(tab.id, { type: "MS_GET_PAGE_INFO" });
      pageInfo = { ...pageInfo, ...info };
      byId("page-title").textContent = pageInfo.title;
      byId("page-domain").textContent = pageInfo.domain;
    } catch { byId("extract-status").textContent = "This page blocks extension extraction. Try the right-click context menu on selected text."; }
  }
});

byId("language").addEventListener("change", () => chrome.storage.sync.set({ language: byId("language").value }));
articleButton.addEventListener("click", () => runAnalysis("article"));
selectedButton.addEventListener("click", () => runAnalysis("selection"));

async function runAnalysis(mode) {
  const tab = currentTab;
  if (!tab?.id) return;
  const startedAt = Date.now();
  let analysisRequestSent = false;
  const timer = setInterval(() => {
    byId("extract-status").textContent = `Analysis running · ${Math.floor((Date.now() - startedAt) / 1000)} seconds elapsed.`;
  }, 1000);
  setBusy(true);
  renderMessage("Preparing analysis", "Extracting article content…", "risk-unable");
  try {
    await chrome.storage.session.remove(["latestAnalysis", "latestError"]);
    await chrome.storage.session.set({ analysisInProgress: true });
    await withTimeout(chrome.runtime.sendMessage({ type: "MS_OPEN_PANEL", tabId: tab.id }), 5000, "Could not open the results panel.");
    await withTimeout(chrome.runtime.sendMessage({ type: "MS_ANALYSIS_PROGRESS", stage: "extracting", message: "Extracting article content…" }), 5000, "The extension could not update its progress panel.");
    const extractionStarted = performance.now();
    await withTimeout(chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] }), 8000, "Page access timed out. Reload the webpage and try again.");
    let text;
    if (mode === "article") {
      const extracted = await withTimeout(chrome.tabs.sendMessage(tab.id, { type: "MS_EXTRACT_ARTICLE" }), 8000, "Article extraction timed out after 8 seconds. Try selecting the article text and use Analyze selected text.");
      if (extracted?.error) throw new Error(extracted.error);
      text = extracted?.text || "";
      const { text: _articleText, ...metadata } = extracted || {};
      pageInfo = { ...pageInfo, ...metadata };
      if (text.length < 80) throw new Error("Could not find enough article text. Select a paragraph and use Analyze selected text, or right-click it and choose Check with Misinformation Shield.");
      byId("extract-status").textContent = `Extracted ${text.length.toLocaleString()} characters (${extracted.extractionMethod}).`;
    } else {
      const [selection] = await withTimeout(chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => window.getSelection()?.toString()?.trim() || "" }), 8000, "Could not read the selected text. Try selecting it again.");
      text = selection?.result || "";
      if (text.length < 30) throw new Error("Select at least a short paragraph on the page first.");
      text = text.slice(0, 100000);
      pageInfo = { ...pageInfo, selectedText: true };
    }
    const extractionMs = Math.round(performance.now() - extractionStarted);
    pageInfo.extractionMs = extractedDuration(pageInfo, extractionMs);
    byId("extract-status").textContent = `Extracted ${text.length.toLocaleString()} characters in ${extractionMs} ms.`;
    await chrome.runtime.sendMessage({ type: "MS_ANALYSIS_PROGRESS", stage: "classifying", message: "Identifying claims and running the trained classifier…" });
    analysisRequestSent = true;
    const response = await chrome.runtime.sendMessage({ type: "MS_ANALYZE_TEXT", text, language: byId("language").value, page: pageInfo });
    if (!response?.ok) throw new Error(response?.error || "The backend could not complete the request.");
    renderPreliminary(response.payload);
  } catch (error) {
    if (!analysisRequestSent) await chrome.runtime.sendMessage({ type: "MS_ANALYSIS_CANCELLED", reason: error.message }).catch(() => {});
    renderMessage("Could not complete analysis", error.message || "Check that the backend is running and the page allows extraction.", "risk-unable");
  } finally { clearInterval(timer); setBusy(false); }
}

function withTimeout(promise, timeoutMs, message) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), timeoutMs); })
  ]).finally(() => clearTimeout(timer));
}
function extractedDuration(metadata, fallback) {
  return typeof metadata.extractionDurationMs === "number" ? metadata.extractionDurationMs : fallback;
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "MS_PRELIMINARY_READY") renderPreliminary(message.payload);
  if (message?.type === "MS_ANALYSIS_UPDATED") renderAnalysis(message.payload.result);
  if (message?.type === "MS_DETAIL_FAILED") {
    chrome.storage.session.get("latestError").then(({ latestError }) => {
      byId("extract-status").textContent = latestError || "Evidence verification did not finish; the preliminary result is not final.";
    });
  }
  if (message?.type === "MS_ANALYSIS_PROGRESS" && !articleButton.disabled) byId("extract-status").textContent = message.message;
});

async function saveSettings() {
  const value = byId("api-base").value.trim().replace(/\/+$/, "");
  let parsed;
  try { parsed = new URL(value); } catch { renderMessage("Invalid backend URL", "Enter a complete URL such as http://127.0.0.1:8000", "risk-unable"); return; }
  if (!( ["http:", "https:"].includes(parsed.protocol)) || parsed.username || parsed.password) { renderMessage("Invalid backend URL", "Use an HTTP or HTTPS URL without embedded credentials.", "risk-unable"); return; }
  const originPattern = `${parsed.protocol}//${parsed.host}/*`;
  const permitted = await chrome.permissions.contains({ origins: [originPattern] });
  if (!permitted) {
    const granted = await chrome.permissions.request({ origins: [originPattern] });
    if (!granted) { renderMessage("Backend permission not granted", "Chrome needs access to this backend host to send your request.", "risk-unable"); return; }
  }
  await chrome.storage.sync.set({ apiBase: value });
  checkBackend(value);
  renderMessage("Backend saved", `Requests will go to ${parsed.origin}.`, "risk-genuine");
}
byId("save-settings").addEventListener("click", saveSettings);

async function checkBackend(base) {
  const status = byId("api-status");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3000);
  try {
    const normalizedBase = base.endsWith("/") ? base.slice(0, -1) : base;
    const response = await fetch(`${normalizedBase}/health`, { signal: controller.signal });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const health = await response.json();
    if (health.status !== "ok") throw new Error("Unexpected health response");
    const index = health.evidence_index || {};
    status.textContent = index.en === "loading"
      ? "Backend connected. English evidence index is warming in the background."
      : "Backend connected and ready.";
    status.className = "status online";
  } catch {
    status.textContent = "Backend unavailable. Start FastAPI and check Backend settings.";
    status.className = "status offline";
  } finally { clearTimeout(timer); }
}

function renderAnalysis(data) {
  const label = data.label || "Unable to Assess";
  const risk = label === "Likely Genuine" ? "risk-genuine" : label === "Potentially Misleading" ? "risk-misleading" : "risk-unable";
  const score = typeof data.classifier_score === "number" ? `${Math.round(data.classifier_score * 100)}% classifier score` : "Classifier score unavailable";
  const claims = (data.claims || []).slice(0, 3).map((claim, i) => `<li><b>Claim ${i + 1}: ${escapeHtml(claim.label || "Unable to Assess")}</b><br>${escapeHtml(claim.claim || "")}</li>`).join("");
  output.className = `result-card ${risk}`;
  output.innerHTML = `<div class="result-heading"><div class="result-icon">✦</div><div class="result-title">${escapeHtml(label)}</div></div><p>${escapeHtml(data.explanation || "Review the source records before reaching a conclusion.")}</p><div class="signal-row"><span class="signal-pill">Model: ${escapeHtml(data.classifier_label || "Unavailable")}</span><span class="signal-pill">${escapeHtml(score)}</span><span class="signal-pill">${Number(data.evidence_summary?.matching_records || 0)} records</span></div><p class="muted">${escapeHtml(data.evidence_status || "Evidence status unavailable")}</p>${claims ? `<details><summary>Extracted claims (${data.claims.length})</summary><ul>${claims}</ul></details>` : ""}<button id="open-details" class="secondary" type="button">Open detailed analysis</button>`;
  byId("open-details").addEventListener("click", () => chrome.runtime.sendMessage({ type: "MS_OPEN_PANEL", tabId: currentTab.id }));
}
function renderPreliminary(payload) {
  const data = payload.result || {};
  const label = data.preliminary_label || "Unable to Assess";
  const score = typeof data.classifier_score === "number" ? `${Math.round(data.classifier_score * 100)}% model score` : "No model score available";
  output.className = "result-card risk-unable";
  output.innerHTML = `<div class="result-heading"><div class="result-icon">◷</div><div class="result-title">Preliminary model signal</div></div><p><b>${escapeHtml(label)}</b></p><p>${escapeHtml(data.explanation || "Evidence verification has not finished.")}</p><div class="signal-row"><span class="signal-pill">Classifier: ${escapeHtml(data.classifier_label || "Unavailable")}</span><span class="signal-pill">${escapeHtml(score)}</span></div><p class="muted">Evidence verification is in progress. This is not the final assessment.</p>`;
  byId("extract-status").textContent = "Preliminary result ready; fact-check evidence is being retrieved in the background.";
}
function renderMessage(title, message, risk) { output.className = `result-card ${risk}`; output.innerHTML = `<b>${escapeHtml(title)}</b><p>${escapeHtml(message)}</p>`; }
function setBusy(busy) { articleButton.disabled = busy || !currentTab?.id; selectedButton.disabled = busy || !currentTab?.id; articleButton.textContent = busy ? "◌  Analyzing…" : "✦  Analyze this article"; }
function safeDomain(value) { try { return new URL(value).hostname; } catch { return ""; } }
function safeProtocol(value) { try { return new URL(value).protocol; } catch { return ""; } }
function escapeHtml(value) { const node = document.createElement("span"); node.textContent = String(value ?? ""); return node.innerHTML; }
