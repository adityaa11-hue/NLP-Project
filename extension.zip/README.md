# Misinformation Shield browser extension

Chrome Manifest V3 extension (also compatible with current Microsoft Edge) that sends user-selected article text to this project's existing FastAPI `/analyze` endpoint. It does not include a second classifier or generate sample predictions.

## Start the existing backend

In PowerShell, from the project root:

```powershell
.\.venv\Scripts\Activate.ps1
python -m uvicorn api.main:app --host 127.0.0.1 --port 8000
```

Check `http://127.0.0.1:8000/health`; the response should be `{"status":"ok"}`. Keep this terminal running while using the extension. Google Fact Check API results still require `GOOGLE_FACT_CHECK_API_KEY` in the backend environment; local X-FACT retrieval uses the existing backend configuration.

## Install in Chrome or Edge

1. Open `chrome://extensions` (Chrome) or `edge://extensions` (Edge).
2. Turn on **Developer mode**.
3. Select **Load unpacked**.
4. Select this project's `extension` folder.
5. Pin **Misinformation Shield** if desired.

After changing extension files, use the extension page's **Reload** control.

## Use

- Open an article webpage, click the extension icon, choose English or Hindi, then select **Analyze this article**. Extraction prefers article/main content and removes common navigation, footer, ad, and form elements. It falls back to substantial page paragraphs if no article container exists.
- To check a passage, select it on the webpage and use **Analyze selected text** in the popup. Or right-click the selection and choose **Check with Misinformation Shield**. The context-menu flow uses the currently selected language.
- Analysis opens the side panel, which shows the overall label, claim-level backend labels, classifier scores, retrieved fact-check records, relevance scores, published rating direction, and source links.
- Expand **Backend settings** in the popup to set a different API base URL. Chrome asks for permission to access that host. Use HTTPS for a deployed service. The local default is `http://127.0.0.1:8000`.

Article text is sent only after the user starts an analysis. The extension holds the submitted text briefly in in-memory session storage only until the side panel picks up the detailed request, then removes it. The article text is not included in saved result metadata. The latest result and page metadata remain in session storage while the browser session is open. The backend caches its X-FACT search index on disk, so after the first index build, subsequent API and backend restarts reuse it. This is screening output, not a factual guarantee.

## Existing API contract

The extension first calls `POST {backend}/analyze/initial` with JSON `{ "text": "...", "language": "en" | "hi" }`. This invokes the saved classifier and returns an explicitly preliminary signal; it always keeps the final `label` at **Unable to Assess** while verification is pending. It then calls `POST {backend}/analyze` for the existing evidence-aware final result. `/health` reports whether the English/Hindi evidence indexes are not started, loading, ready, or in error. No credentials are sent from the extension.

## Limitations

- Browser internal pages, extension stores, PDF viewers, and some protected/dynamic pages block script-based extraction. Selectable webpage text may still work where browser permissions allow it.
- Short text can produce **Unable to Assess** because the existing backend requires enough context and verifiable claims.
- The backend's existing model/evidence limits remain; the extension does not upgrade model accuracy. The preliminary classifier output is a model signal, never a verified truth result.
- Google Fact Check API availability depends on backend configuration, key validity, quota, and network access.
- A remote backend must allow extension-origin CORS requests. The current API CORS middleware permits all origins by default; deploy with an explicit origin policy where appropriate.

## Automated checks

From the project root, validate manifest JSON and JavaScript syntax with:

```powershell
Get-Content extension\manifest.json -Raw | ConvertFrom-Json | Out-Null
node --check extension\background.js
node --check extension\content.js
node --check extension\popup.js
node --check extension\sidepanel.js
```

Then follow the manual installation steps above to verify Chrome UI behavior.
